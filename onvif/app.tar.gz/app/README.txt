服务端的一些配置在 src/soap/macro.h 文件中，修改下ip就可以正常运行了。

编译：make clean，make
运行：./output/debug/app

如果要获取RTSP流，进入res目录下，直接运行live555MediaServer
